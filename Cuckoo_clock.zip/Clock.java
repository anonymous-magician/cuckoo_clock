import java.awt.*;
import java.util.Date;
import java.net.URL;

import java.io.File;
import java.io.IOException;
import javax.sound.sampled.*; //pentru sunet

class Clock extends Frame implements Runnable {
	//culoarea fundalului, a acelor si a textului
	Color bgcolor = new Color(0,0,0);
	Color orar = new Color(60,60,60);
	Color minutar = new Color(26,0,153); //ultramarine blue
	Color secundar = new Color(255,0,0);
	Color digital = new Color(0,0,0);
	Color centru = new Color(60,60,60);
	
	//fontul folosit la ceasul digital
	Font f = new Font("Helvetica", 1, 22);
	FontMetrics fm = getFontMetrics(f);
	Thread t;
	Image im, cim, cim00;
	Graphics imgr; 
	int w, h, wd, hd;
	
	//ora, minutul, secunda
	int hh, mm, ss;
	int counter=0;
	int s0=-1;
	
	//lungimea secundarului, minutarului, orarului
	int rs=90, rm=75, rh=60;  //secundar = 267- 176=91;  minutar = 252 - 176=76; orar = 238-176=62
	int dh=22, dm=16; //grosimea orarului si a minutarului
	int rc = 16; //raza cercului secundar
	
	//(x0,y0) coord centrului ceasului, (x1,y1) coord varfului unui ac
	int x0=176, y0=234, x1, y1;
	
	//(x2,y2) unde se afiseaza ceasul digital
	int x2, y2=133;
	
	//unghiul minutarului, orarului, secundarului
	double fim, fih, fis;
	double PI2 = 2*Math.PI;
	Date d; //data sistemului
	int delay = 100; //nr de milisecunde intre doua redesenari
	int Ox = 5, Oy = 30;
	public static final String[] zile = {"Duminic\u0103", "Luni", "Mar\u021Bi", "Miercuri", "Joi", "Vineri", "S\u00E2mb\u0103t\u0103"};
	
	public static void main(String[] args)
	{
		new Clock();
	}
 
	Clock()
	{
		Toolkit tool = getToolkit();
		cim = tool.getImage(getResource("imagini/clock.png"));
		cim00 = tool.getImage(getResource("imagini/clock00.gif"));
		setIconImage(tool.getImage(getResource("imagini/ico.gif")));
		//setBackground(bgcolor);
		Dimension res=tool.getScreenSize();
		wd = res.width; hd = res.height; //dimensiunile display-ului
		w = 348; h = 348; //dimensiunile imaginii de fundal
		int wf = w + 10, hf = h + 20; //dimensiunile ferestrei
		setResizable(false);
		resize(wf,hf);
		move((wd-wf)/2,(hd-hf)/2); 
		show();
		im = createImage(w, h);
		imgr = im.getGraphics();
		t = new Thread(this); 
		t.start();
	}
	
	public URL getResource(String path)
	{
		return getClass().getResource(path);
	}
	 
	public void run()
	{
		while(true) 
		{
			repaint();
			try{Thread.sleep(delay);}
			catch(Exception e){return;}
		}
	} 
	
	public void paint(Graphics g)
	{
		update(g);
	}
	
	public void update(Graphics g)
	{	
		//obtinerea orei, minutului, secundei
		Date date = new Date();
		hh = date.getHours();
		mm = date.getMinutes();
		ss = date.getSeconds();
		 
		fis = (PI2 * (double)ss) / 60D;
		fim = (PI2 * (double)mm + fis) / 60D;
		fih = (PI2 * (double)(hh % 12) + fim) / 12D;
		
		//sunetul ceasului
		if (mm == 0 && counter < hh+1)
		{
			if (s0 != ss)
			{
				s0 = ss;            
				counter++;
				playSound("cuckoo_sound_effect.au", false);
			}
		}
		if (mm != 0) s0 = -1; // pt ca dam repaint la imagine de mai multe ori pe secunda, verificam sa fie diferita secunda precedenta de secunda curenta
		if (mm == 59) counter = 0; // counter numara de cate ori trebuie sa cante cucul
		 
		//desenarea ceasului
		if (mm == 00 && (ss >= 0 && ss <= hh+0.5)) 
		{
			//imgr.setColor(bgcolor); //imaginea mea nu e transparenta
			//imgr.fillRect(0, 0, w, h);
			imgr.drawImage(cim00, 0, 0, this);
		}
		else
		{
			//imgr.setColor(bgcolor);
			//imgr.fillRect(0, 0, w, h);
			imgr.drawImage(cim, 0, 0, this);
		}
		 
		//AM sau PM
		String s = "AM";
		if(hh >= 12)s = "PM";
		hh = hh % 12;
		if(hh == 0)hh = 12;
		 
		//afisajul digital
		imgr.setColor(digital);
		int d1 = hh / 10;
		int d2 = hh % 10;
		int d3 = mm / 10;
		int d4 = mm % 10;
		int d5 = ss / 10;
		int d6 = ss % 10;
		imgr.setFont(f);
		String ss = d1 + "" + d2 + ":" + d3 + "" + d4 + " " + s;
		x2 = 174 - fm.stringWidth(ss)/2;
		imgr.drawString(ss, x2, y2);
		hh = date.getHours();
		d1 = hh / 10;
		d2 = hh % 10;
		ss = d1 + "" + d2 + ":" + d3 + "" + d4 + ":" + d5 + "" + d6 + " / ";
		ss += zile[date.getDay()] + " ";
		ss += date.getDate() / 10 + "" + date.getDate() % 10 + ".";
		ss += date.getMonth() / 10 + "" + date.getMonth() % 10 + "."; 
		ss += date.getYear()+1900;
		setTitle(ss);
		 
		//desenarea acelor
			// orarul
			x1 = (int)((double)x0 + (double)rh * Math.sin(fih));
			y1 = (int)(((double)y0 - (double)rh * Math.cos(fih)));
			imgr.setColor(orar);
			int xm = (x0+x1)/2;
			int ym = (y0+y1)/2;
			double t = 0.75;
			int x2 = (int)(x0+(xm-x0)*t);
			int y2 = (int)(y0+(ym-y0)*t);
			int x3 = (int)(x1+(xm-x1)*t);
			int y3 = (int)(y1+(ym-y1)*t);
				// poligonul de la baza acului
				double dx = x2 - x0;
				double dy = y2 - y0;
				double lungime = Math.sqrt(dx*dx + dy*dy);
				double perpX = -dy / lungime * 2;  
				double perpY = dx / lungime * 2;
				int[] xPoly = {(int)(x0 - perpX), (int)(x2 - perpX), (int)(x2 + perpX), (int)(x0 + perpX)};
				int[] yPoly = {(int)(y0 - perpY), (int)(y2 - perpY), (int)(y2 + perpY), (int)(y0 + perpY)};
				imgr.fillPolygon(xPoly, yPoly, 4);
				// poligonul de la varful acului
				double dx1 = x3 - x1;
				double dy1 = y3 - y1;
				double lungime1 = Math.sqrt(dx1*dx1 + dy1*dy1);
				double perpX1 = -dy1 / lungime1 * 2;
				double perpY1 = dx1 / lungime1 * 2;
				int[] xPoly1 = {(int)(x1 - perpX1), (int)(x3 - perpX1), (int)(x3 + perpX1), (int)(x1 + perpX1)};
				int[] yPoly1 = {(int)(y1 - perpY1), (int)(y3 - perpY1), (int)(y3 + perpY1), (int)(y1 + perpY1)};
				imgr.fillPolygon(xPoly1, yPoly1, 4);
				//cercul mare
				int r = (int)(rh*(1-t)/2. * 1.3);
				imgr.drawOval(xm-r, ym-r, 2*r, 2*r);
				imgr.drawOval(xm-r+1, ym-r+1, 2*r-2, 2*r-2);
				// deseneaza E-ul
				double cos_unghi = Math.cos(fih);
				double sin_unghi = Math.sin(fih);
				int[] e_x1 = {-3, -3, -3, -3};
				int[] e_y1 = {-5, 0, 5, -5};
				int[] e_x2 = {3, 1, 3, -3};
				int[] e_y2 = {-5, 0, 5, 5};
				for (int i = 0; i < 4; i++)
				{
					int x1_e = xm + (int)(e_x1[i] * cos_unghi - e_y1[i] * sin_unghi);
					int y1_e = ym + (int)(e_x1[i] * sin_unghi + e_y1[i] * cos_unghi);
					int x2_e = xm + (int)(e_x2[i] * cos_unghi - e_y2[i] * sin_unghi);
					int y2_e = ym + (int)(e_x2[i] * sin_unghi + e_y2[i] * cos_unghi);
					imgr.drawLine(x1_e, y1_e, x2_e, y2_e);
					imgr.drawLine(x1_e+1, y1_e, x2_e+1, y2_e);
					imgr.drawLine(x1_e-1, y1_e, x2_e-1, y2_e);
				}
				//cercul de la baza acului
				int r_cerc_baza = 2;
				imgr.drawOval(x0 - r_cerc_baza, y0 - r_cerc_baza, 2 * r_cerc_baza, 2 * r_cerc_baza);

			// minutarul
			x1 = (int)((double)x0 + (double)rm * Math.sin(fim));
			y1 = (int)(((double)y0 - (double)rm * Math.cos(fim)));
			imgr.setColor(minutar);
			xm = (x0+x1)/2;
			ym = (y0+y1)/2;
			t = 0.75;
			x2 = (int)(x0+(xm-x0)*t);
			y2 = (int)(y0+(ym-y0)*t);
			x3 = (int)(x1+(xm-x1)*t);
			y3 = (int)(y1+(ym-y1)*t);
				// poligonul de la baza acului
				dx = x2 - x0;
				dy = y2 - y0;
				lungime = Math.sqrt(dx*dx + dy*dy);
				perpX = -dy / lungime * 2;  
				perpY = dx / lungime * 2;
				xPoly = new int[]{(int)(x0 - perpX), (int)(x2 - perpX), (int)(x2 + perpX), (int)(x0 + perpX)};
				yPoly = new int[]{(int)(y0 - perpY), (int)(y2 - perpY), (int)(y2 + perpY), (int)(y0 + perpY)};
				imgr.fillPolygon(xPoly, yPoly, 4);
				// poligonul de la varful acului
				dx1 = x3 - x1;
				dy1 = y3 - y1;
				lungime1 = Math.sqrt(dx1*dx1 + dy1*dy1);
				perpX1 = -dy1 / lungime1 * 2;
				perpY1 = dx1 / lungime1 * 2;
				xPoly1 = new int[]{(int)(x1 - perpX1), (int)(x3 - perpX1), (int)(x3 + perpX1), (int)(x1 + perpX1)};
				yPoly1 = new int[]{(int)(y1 - perpY1), (int)(y3 - perpY1), (int)(y3 + perpY1), (int)(y1 + perpY1)};
				imgr.fillPolygon(xPoly1, yPoly1, 4);
				//cercul mare
				r = (int)(rm*(1-t)/2. * 1.2);
				imgr.drawOval(xm-r, ym-r, 2*r, 2*r);
				imgr.drawOval(xm-r+1, ym-r+1, 2*r-2, 2*r-2);
				imgr.drawOval(xm-r-1, ym-r-1, 2*r+2, 2*r+2);
				// deseneaza U-ul
				cos_unghi = Math.cos(fim);
				sin_unghi = Math.sin(fim);
				int[] uxRel = {-4, -4, -3, 0, 3, 4, 4};
				int[] uyRel = {-7, 6, 7, 7, 7, 6, -7};
				for (int i = 0; i < uxRel.length - 1; i++) 
				{
					int x1u = xm + (int)(uxRel[i] * cos_unghi - uyRel[i] * sin_unghi);
					int y1u = ym + (int)(uxRel[i] * sin_unghi + uyRel[i] * cos_unghi);
					int x2u = xm + (int)(uxRel[i+1] * cos_unghi - uyRel[i+1] * sin_unghi);
					int y2u = ym + (int)(uxRel[i+1] * sin_unghi + uyRel[i+1] * cos_unghi);
					imgr.drawLine(x1u, y1u, x2u, y2u);
					imgr.drawLine(x1u+1, y1u-1, x2u+1, y2u-1);
					imgr.drawLine(x1u-1, y1u-2, x2u-1, y2u-2);
					//imgr.drawLine(x1u-2, y1u, x2u-2, y2u);

				}
				//cercul de la baza acului
				r_cerc_baza = 4;
				imgr.drawOval(x0 - r_cerc_baza, y0 - r_cerc_baza, 2 * r_cerc_baza, 2 * r_cerc_baza);
				imgr.drawOval(x0 - r_cerc_baza + 1, y0 - r_cerc_baza + 1, 2 * r_cerc_baza - 2, 2 * r_cerc_baza - 2);


		//desenarea imaginii
		g.drawImage(im, Ox, Oy, this);
	}
	
	Point[] puncte(Point p1, Point p2, double d1, double d2)
	{ 	
		//d1=diagonala mica, d2=diagonala mare
		Point[] p = new Point[2];
		if(Math.abs(p1.y - p2.y)>10)
		{
			int a = (int)((d1/d2)*Math.abs(p1.y-p2.y)+0.5);
			double m = -(double)(p1.x-p2.x)/(p1.y-p2.y);
			int xm = (p1.x+p2.x)/2;
			int ym = (p1.y+p2.y)/2;
			p[0] = new Point(xm+a, ym+(int)(m*a+0.5));
			p[1] = new Point(xm-a, ym-(int)(m*a+0.5));
		}
		else
		{
			int a = (int)((d1/d2)*Math.abs(p1.x-p2.x)+0.5);
			double m = -(double)(p1.y-p2.y)/(p1.x-p2.x);
			int xm = (p1.x+p2.x)/2;
			int ym = (p1.y+p2.y)/2;
			p[0] = new Point(xm+(int)(m*a+0.5), ym+a);
			p[1] = new Point(xm-(int)(m*a+0.5), ym-a);
		}
		
		return p;
	}
	
	public boolean handleEvent(Event e)
	{
		if(e.id==Event.WINDOW_DESTROY){System.exit(0);} 
		return super.handleEvent(e);
	}
	
	void playSound(String nume_fisier_sunet, boolean repeta) {
		try{
			String res = System.getProperty("user.dir")+"/sunete/";
			String soundFile = res + nume_fisier_sunet;
			File fin = new File(soundFile).getAbsoluteFile();
			AudioInputStream ais = AudioSystem.getAudioInputStream(fin); 
			Clip clip = AudioSystem.getClip(); 
			clip.open(ais); 
			clip.loop(0); 
			clip.start(); 		
			if(repeta) clip.loop(Clip.LOOP_CONTINUOUSLY);                			
		}
		catch(IOException e){e.printStackTrace();}
		catch(UnsupportedAudioFileException e){e.printStackTrace();}
		catch(LineUnavailableException e){e.printStackTrace();}
	}
}
